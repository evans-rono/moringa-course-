<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes API</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f5f5f5;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        h1 {
            color: #333;
            margin-bottom: 30px;
        }
        .note-form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .note-form h2 {
            margin-bottom: 15px;
            color: #555;
            font-size: 18px;
        }
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            font-family: inherit;
            resize: vertical;
            min-height: 100px;
        }
        button {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
        }
        button:hover {
            background: #0056b3;
        }
        button.danger {
            background: #dc3545;
        }
        button.danger:hover {
            background: #c82333;
        }
        button.secondary {
            background: #6c757d;
        }
        button.secondary:hover {
            background: #5a6268;
        }
        .notes-list {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .note-item {
            padding: 20px;
            border-bottom: 1px solid #eee;
        }
        .note-item:last-child {
            border-bottom: none;
        }
        .note-content {
            color: #333;
            margin-bottom: 10px;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .note-meta {
            color: #999;
            font-size: 12px;
            margin-bottom: 10px;
        }
        .note-actions {
            display: flex;
            gap: 10px;
        }
        .message {
            padding: 12px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .edit-mode textarea {
            margin-bottom: 10px;
        }
        #messageContainer {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Notes API</h1>

    <div id="messageContainer"></div>

    <div class="note-form">
        <h2 id="formTitle">Create New Note</h2>
        <form id="noteForm">
            <textarea id="noteContent" name="content" placeholder="Enter your note content..." required maxlength="1000"></textarea>
            <button type="submit" id="submitBtn">Create Note</button>
            <button type="button" id="cancelBtn" style="display: none;" class="secondary">Cancel</button>
        </form>
    </div>

    <div class="notes-list">
        <div id="notesContainer">
            <div style="padding: 20px; text-align: center; color: #999;">Loading notes...</div>
        </div>
    </div>

    <script>
        let editingNoteId = null;

        // Load all notes on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadNotes();
        });

        // Form submission handler
        document.getElementById('noteForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const content = document.getElementById('noteContent').value.trim();
            
            if (!content) {
                showMessage('Please enter note content', 'error');
                return;
            }

            if (editingNoteId) {
                updateNote(editingNoteId, content);
            } else {
                createNote(content);
            }
        });

        // Cancel edit handler
        document.getElementById('cancelBtn').addEventListener('click', function() {
            resetForm();
        });

        // Load all notes
        async function loadNotes() {
            try {
                const response = await fetch('/api/notes');
                const result = await response.json();

                if (result.success) {
                    displayNotes(result.data);
                } else {
                    showMessage(result.message || 'Failed to load notes', 'error');
                }
            } catch (error) {
                showMessage('Error loading notes: ' + error.message, 'error');
            }
        }

        // Create a new note
        async function createNote(content) {
            try {
                const response = await fetch('/api/notes', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({ content })
                });

                const result = await response.json();

                if (result.success) {
                    showMessage('Note created successfully', 'success');
                    document.getElementById('noteForm').reset();
                    loadNotes();
                } else {
                    const errorMsg = result.errors?.content?.[0] || result.message || 'Failed to create note';
                    showMessage(errorMsg, 'error');
                }
            } catch (error) {
                showMessage('Error creating note: ' + error.message, 'error');
            }
        }

        // Update an existing note
        async function updateNote(id, content) {
            try {
                const response = await fetch(`/api/notes/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({ content })
                });

                const result = await response.json();

                if (result.success) {
                    showMessage('Note updated successfully', 'success');
                    resetForm();
                    loadNotes();
                } else {
                    const errorMsg = result.errors?.content?.[0] || result.message || 'Failed to update note';
                    showMessage(errorMsg, 'error');
                }
            } catch (error) {
                showMessage('Error updating note: ' + error.message, 'error');
            }
        }

        // Delete a note
        async function deleteNote(id) {
            if (!confirm('Are you sure you want to delete this note?')) {
                return;
            }

            try {
                const response = await fetch(`/api/notes/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'Accept': 'application/json'
                    }
                });

                const result = await response.json();

                if (result.success) {
                    showMessage('Note deleted successfully', 'success');
                    loadNotes();
                } else {
                    showMessage(result.message || 'Failed to delete note', 'error');
                }
            } catch (error) {
                showMessage('Error deleting note: ' + error.message, 'error');
            }
        }

        // Display notes in the UI
        function displayNotes(notes) {
            const container = document.getElementById('notesContainer');

            if (notes.length === 0) {
                container.innerHTML = '<div style="padding: 20px; text-align: center; color: #999;">No notes yet. Create your first note above!</div>';
                return;
            }

            container.innerHTML = notes.map(note => {
                const createdDate = new Date(note.created_at).toLocaleString();
                const updatedDate = new Date(note.updated_at).toLocaleString();
                const isUpdated = note.created_at !== note.updated_at;
                const jsonContent = JSON.stringify(note.content);

                return `
                    <div class="note-item" id="note-${note.id}">
                        <div class="note-meta">
                            Created: ${createdDate}${isUpdated ? ' | Updated: ' + updatedDate : ''}
                        </div>
                        <div class="note-content" id="content-${note.id}">${escapeHtml(note.content)}</div>
                        <div class="note-actions">
                            <button onclick="editNoteFromData(${note.id})" data-content='${jsonContent}'>Edit</button>
                            <button onclick="deleteNote(${note.id})" class="danger">Delete</button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Edit a note (called from onclick with data attribute)
        function editNoteFromData(id) {
            const button = event.target;
            const jsonContent = button.getAttribute('data-content');
            const content = JSON.parse(jsonContent);
            editNote(id, content);
        }

        // Edit a note
        function editNote(id, content) {
            editingNoteId = id;
            document.getElementById('noteContent').value = content;
            document.getElementById('formTitle').textContent = 'Edit Note';
            document.getElementById('submitBtn').textContent = 'Update Note';
            document.getElementById('cancelBtn').style.display = 'inline-block';
            document.getElementById('noteContent').focus();
        }

        // Reset form to create mode
        function resetForm() {
            editingNoteId = null;
            document.getElementById('noteForm').reset();
            document.getElementById('formTitle').textContent = 'Create New Note';
            document.getElementById('submitBtn').textContent = 'Create Note';
            document.getElementById('cancelBtn').style.display = 'none';
        }

        // Show message to user
        function showMessage(message, type) {
            const container = document.getElementById('messageContainer');
            container.innerHTML = `<div class="message ${type}">${escapeHtml(message)}</div>`;
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                container.innerHTML = '';
            }, 5000);
        }

        // Escape HTML to prevent XSS
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
</body>
</html>

<?php /**PATH /Users/meshack/Desktop/projects/notes/resources/views/app.blade.php ENDPATH**/ ?>
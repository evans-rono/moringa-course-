# Notes API

A minimal Notes API application for testing REST APIs. This application provides CRUD functionality for notes via a REST API with a single-page Blade frontend.

## Features

- RESTful API endpoints for note management
- Single-page frontend using vanilla JavaScript
- SQLite database (default Laravel configuration)
- No authentication, pagination, or extra features - minimal and focused

## Requirements

- PHP 8.2 or higher
- Composer
- SQLite (included with PHP)

## Setup Instructions

1. **Install dependencies** (if not already installed):
   ```bash
   composer install
   ```

2. **Configure environment**:
   The application is already configured to use SQLite. The database file is located at `database/database.sqlite`.

3. **Run migrations**:
   ```bash
   php artisan migrate
   ```

4. **Start the development server**:
   ```bash
   php artisan serve
   ```

5. **Access the application**:
   Open your browser and navigate to:
   ```
   http://localhost:8000
   ```

## API Endpoints

All API endpoints return JSON responses in the following format:
```json
{
  "success": true|false,
  "data": <payload or null>,
  "message": "Human readable message"
}
```

### Available Endpoints

- `GET /api/notes` - Retrieve all notes
- `POST /api/notes` - Create a new note
  - Body: `{"content": "Your note content"}`
- `PUT /api/notes/{id}` - Update an existing note
  - Body: `{"content": "Updated note content"}`
- `DELETE /api/notes/{id}` - Delete a note

### Validation Rules

- `content`: required, string, maximum 1000 characters

## Project Structure

```
notes/
├── app/
│   ├── Http/Controllers/Api/
│   │   └── NoteController.php
│   └── Models/
│       └── Note.php
├── database/
│   ├── migrations/
│   │   └── 2025_12_18_165712_create_notes_table.php
│   └── database.sqlite
├── routes/
│   ├── api.php
│   └── web.php
└── resources/views/
    └── app.blade.php
```

## Usage

1. **View all notes**: The frontend automatically loads all notes when you visit the page.

2. **Create a note**: Enter your note content in the textarea and click "Create Note".

3. **Edit a note**: Click the "Edit" button on any note, modify the content, and click "Update Note".

4. **Delete a note**: Click the "Delete" button on any note and confirm the deletion.

## Testing the API

You can test the API endpoints directly using curl or any API client:

```bash
# Get all notes
curl http://localhost:8000/api/notes

# Create a note
curl -X POST http://localhost:8000/api/notes \
  -H "Content-Type: application/json" \
  -d '{"content": "This is a test note"}'

# Update a note (replace {id} with actual note ID)
curl -X PUT http://localhost:8000/api/notes/1 \
  -H "Content-Type: application/json" \
  -d '{"content": "Updated note content"}'

# Delete a note (replace {id} with actual note ID)
curl -X DELETE http://localhost:8000/api/notes/1
```

## Notes

- The application uses SQLite for simplicity - no additional database setup required
- All API routes are prefixed with `/api`
- The frontend uses vanilla JavaScript with the Fetch API - no frameworks required
- Route-model binding is used for update and delete operations

